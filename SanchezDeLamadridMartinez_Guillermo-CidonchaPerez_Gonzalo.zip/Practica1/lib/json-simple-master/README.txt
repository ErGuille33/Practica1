Please visit:
http://code.google.com/p/json-simple/