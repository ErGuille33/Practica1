package com.OffTheLine.engine;

public interface Font {

}
